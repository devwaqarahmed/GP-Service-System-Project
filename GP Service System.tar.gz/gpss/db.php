<?php
    $conn=mysqli_connect('localhost','root','','gp_surgery');
